import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/habit.dart';
import '../models/progress.dart';

class HabitProvider extends ChangeNotifier {
  static const _storageKey = 'habits';

  List<Habit> _habits = [];
  List<Habit> get habits => _habits;

  HabitProvider() {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw != null) {
      final decoded = jsonDecode(raw) as List<dynamic>;
      _habits = decoded.map((e) => Habit.fromMap(e)).toList();
    }
    notifyListeners();
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _storageKey,
      jsonEncode(_habits.map((e) => e.toMap()).toList()),
    );
  }

  void addHabit(Habit habit) {
    _habits.add(habit);
    _persist();
    notifyListeners();
  }

  void updateHabit(Habit habit) {
    final idx = _habits.indexWhere((h) => h.id == habit.id);
    if (idx != -1) _habits[idx] = habit;
    _persist();
    notifyListeners();
  }

  void deleteHabit(String id) {
    _habits.removeWhere((h) => h.id == id);
    _persist();
    notifyListeners();
  }

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  void toggleProgress(String habitId, DateTime date) {
    final habit = _habits.firstWhere((h) => h.id == habitId);
    final idx = habit.progress.indexWhere((p) => _isSameDay(p.date, date));

    if (idx == -1) {
      habit.progress.add(Progress(date: date, done: true));
    } else {
      habit.progress[idx].done = !habit.progress[idx].done;
    }
    updateHabit(habit);
  }

  void loadHabits() {}
}