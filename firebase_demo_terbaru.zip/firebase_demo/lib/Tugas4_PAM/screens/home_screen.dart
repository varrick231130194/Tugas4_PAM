import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
// import '../providers/habit_provider.dart';
import '../providers/quote_provider.dart';
import '../providers/auth_provider.dart';
import 'login_screen.dart';
import '../providers/habit_provider copy.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    final habitProvider = Provider.of<HabitProvider2>(context, listen: false);
    final quoteProvider = Provider.of<QuoteProvider>(context, listen: false);
    habitProvider.loadHabits();
    quoteProvider.fetchQuote();
  }

  @override
  Widget build(BuildContext context) {
    final habitProvider = Provider.of<HabitProvider2>(context);
    final quoteProvider = Provider.of<QuoteProvider>(context);
    final auth = Provider.of<AuthProvider>(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text("Habit Tracker"),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await auth.logout();
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
            },
          )
        ],
      ),
      body: Column(
        children: [
          if (quoteProvider.isLoading)
            const CircularProgressIndicator()
          else
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text('"${quoteProvider.quote}"', textAlign: TextAlign.center, style: const TextStyle(fontStyle: FontStyle.italic)),
            ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: controller,
              decoration: InputDecoration(
                labelText: "Add Habit",
                suffixIcon: IconButton(
                  icon: const Icon(Icons.add),
                  onPressed: () {
                    habitProvider.addHabit(controller.text);
                    controller.clear();
                  },
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: habitProvider.habits.length,
              itemBuilder: (context, index) {
                return ListTile(title: Text(habitProvider.habits[index]));
              },
            ),
          )
        ],
      ),
    );
  }
}