import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class QuoteProvider with ChangeNotifier {
  String _quote = '';
  String get quote => _quote;
  bool isLoading = false;

  Future<void> fetchQuote() async {
    isLoading = true;
    notifyListeners();
    final url = Uri.parse("https://api.quotable.io/random");
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _quote = data["content"];
      }
    } catch (e) {
      _quote = "Error loading quote.";
    }
    isLoading = false;
    notifyListeners();
  }
}