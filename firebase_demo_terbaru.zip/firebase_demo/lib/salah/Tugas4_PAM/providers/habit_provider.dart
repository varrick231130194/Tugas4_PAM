import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class HabitProvider with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<String> _habits = [];
  List<String> get habits => _habits;

  Future<void> loadHabits() async {
    final snapshot = await _firestore.collection('habits').get();
    _habits = snapshot.docs.map((doc) => doc['title'] as String).toList();
    notifyListeners();
  }

  Future<void> addHabit(String title) async {
    await _firestore.collection('habits').add({'title': title});
    _habits.add(title);
    notifyListeners();
  }
}