import 'package:demo_app/Tugas3_PAM/providers/habit_provider.dart';
import 'package:demo_app/Tugas3_PAM/providers/user_preferences_provider.dart';
import 'package:demo_app/Tugas3_PAM/screens/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => HabitProvider()),
        ChangeNotifierProvider(create: (_) => UserPreferencesProvider()),
      ],
      child: Consumer<UserPreferencesProvider>(
        builder: (context, prefs, _) {
          return MaterialApp(
            title: 'Habit Tracker',
            debugShowCheckedModeBanner: false,
            theme: ThemeData(
              brightness: Brightness.light,
              colorSchemeSeed: Colors.teal,
              useMaterial3: true,
            ),
            darkTheme: ThemeData(
              brightness: Brightness.dark,
              colorSchemeSeed: const Color.fromARGB(255, 8, 29, 27),
              useMaterial3: true,
            ),
            themeMode: prefs.themeMode,
            home: const HomeScreen(),
          );
        },
      ),
    );
  }
}