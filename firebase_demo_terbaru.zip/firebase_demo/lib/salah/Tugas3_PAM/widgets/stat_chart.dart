import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../models/habit.dart';

class StatChart extends StatelessWidget {
  final Habit habit;
  const StatChart({super.key, required this.habit});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final data = List.generate(7, (i) => 0);

    for (var p in habit.progress) {
      final diff = now.difference(p.date).inDays;
      if (diff >= 0 && diff < 7 && p.done) {
        data[6 - diff] += 1;
      }
    }

    return AspectRatio(
      aspectRatio: 1.7,
      child: BarChart(
        BarChartData(
          titlesData: FlTitlesData(
            show: true,
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  const days = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
                  return Text(days[value.toInt()]);
                },
              ),
            ),
          ),
          borderData: FlBorderData(show: false),
          barGroups: List.generate(7, (i) {
            return BarChartGroupData(
              x: i,
              barRods: [
                BarChartRodData(toY: data[i].toDouble(), width: 14, borderRadius: BorderRadius.circular(4)),
              ],
            );
          }),
        ),
      ),
    );
  }
}