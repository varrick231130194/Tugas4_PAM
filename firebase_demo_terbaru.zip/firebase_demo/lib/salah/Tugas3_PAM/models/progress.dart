class Progress {
  final DateTime date;
  bool done;

  Progress({required this.date, required this.done});

  factory Progress.fromMap(Map<String, dynamic> map) => Progress(
        date: DateTime.parse(map['date']),
        done: map['done'] as bool,
      );

  Map<String, dynamic> toMap() => {
        'date': date.toIso8601String(),
        'done': done,
      };
}