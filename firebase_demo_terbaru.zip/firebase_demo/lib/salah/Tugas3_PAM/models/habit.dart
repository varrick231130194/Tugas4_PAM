import 'dart:convert';
import 'progress.dart';

class Habit {
  final String id;
  String title;
  String icon;
  List<Progress> progress;

  Habit({
    required this.id,
    required this.title,
    required this.icon,
    List<Progress>? progress,
  }) : progress = progress ?? [];

  factory Habit.fromMap(Map<String, dynamic> map) => Habit(
        id: map['id'],
        title: map['title'],
        icon: map['icon'],
        progress: (map['progress'] as List<dynamic>?)?.map((e) => Progress.fromMap(e)).toList() ?? [],
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'icon': icon,
        'progress': progress.map((e) => e.toMap()).toList(),
      };

  String toJson() => jsonEncode(toMap());
  factory Habit.fromJson(String source) => Habit.fromMap(jsonDecode(source));
}