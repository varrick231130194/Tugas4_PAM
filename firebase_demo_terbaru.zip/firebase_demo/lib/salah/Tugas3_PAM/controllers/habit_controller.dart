import 'package:uuid/uuid.dart';

import '../models/habit.dart';
import '../providers/habit_provider.dart';

class HabitController {
  final HabitProvider provider;
  final _uuid = const Uuid();

  HabitController(this.provider);

  void createHabit(String title, String icon) {
    final newHabit = Habit(id: _uuid.v4(), title: title, icon: icon);
    provider.addHabit(newHabit);
  }

  void editHabit(Habit habit, String title, String icon) {
    habit.title = title;
    habit.icon = icon;
    provider.updateHabit(habit);
  }

  void deleteHabit(String id) => provider.deleteHabit(id);

  void toggleToday(Habit habit) => provider.toggleProgress(habit.id, DateTime.now());
}