import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/habit_provider.dart';
import '../widgets/stat_chart.dart';

class StatScreen extends StatelessWidget {
  const StatScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final habits = context.watch<HabitProvider>().habits;
    return Scaffold(
      appBar: AppBar(title: const Text('Statistik')),
      body: habits.isEmpty
          ? const Center(child: Text('Belum ada data'))
          : ListView(
              padding: const EdgeInsets.all(16),
              children: habits
                  .map((h) => Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(h.title, style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 8),
                          StatChart(habit: h),
                          const SizedBox(height: 24),
                        ],
                      ))
                  .toList(),
            ),
    );
  }
}