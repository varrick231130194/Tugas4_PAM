import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/user_preferences_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final prefs = context.watch<UserPreferencesProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Pengaturan')),
      body: Column(
        children: [
          RadioListTile<ThemeMode>(
            title: const Text('Ikuti sistem'),
            value: ThemeMode.system,
            groupValue: prefs.themeMode,
            onChanged: (value) {
              if (value != null) prefs.setThemeMode(value);
            },
          ),
          RadioListTile<ThemeMode>(
            title: const Text('Mode terang'),
            value: ThemeMode.light,
            groupValue: prefs.themeMode,
            onChanged: (value) {
              if (value != null) prefs.setThemeMode(value);
            },
          ),
          RadioListTile<ThemeMode>(
            title: const Text('Mode gelap'),
            value: ThemeMode.dark,
            groupValue: prefs.themeMode,
            onChanged: (value) {
              if (value != null) prefs.setThemeMode(value);
            },
          ),
        ],
      ),
    );
  }
}