import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/habit_controller.dart';
import '../models/habit.dart';
import '../providers/habit_provider.dart';

class AddEditScreen extends StatefulWidget {
  final Habit? habit;
  const AddEditScreen({super.key, this.habit});

  @override
  State<AddEditScreen> createState() => _AddEditScreenState();
}

class _AddEditScreenState extends State<AddEditScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _titleC;
  String _icon = '🔥';

  @override
  void initState() {
    super.initState();
    _titleC = TextEditingController(text: widget.habit?.title ?? '');
    _icon = widget.habit?.icon ?? '🔥';
  }

  @override
  void dispose() {
    _titleC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = HabitController(context.read<HabitProvider>());

    return Scaffold(
      appBar: AppBar(title: Text(widget.habit == null ? 'Tambah Kebiasaan' : 'Edit Kebiasaan')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _titleC,
                decoration: const InputDecoration(labelText: 'Nama Kebiasaan'),
                validator: (v) => (v == null || v.isEmpty) ? 'Wajib diisi' : null,
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Text('Emoji Ikon: '),
                  Text(_icon, style: const TextStyle(fontSize: 32)),
                  IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () async {
                      final chosen = await showDialog<String>(
                        context: context,
                        builder: (_) => const _EmojiPickerDialog(),
                      );
                      if (chosen != null) setState(() => _icon = chosen);
                    },
                  ),
                ],
              ),
              const Spacer(),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    if (widget.habit == null) {
                      controller.createHabit(_titleC.text, _icon);
                    } else {
                      controller.editHabit(widget.habit!, _titleC.text, _icon);
                    }
                    Navigator.pop(context);
                  }
                },
                child: Text(widget.habit == null ? 'Tambah' : 'Simpan'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmojiPickerDialog extends StatelessWidget {
  const _EmojiPickerDialog();
  @override
  Widget build(BuildContext context) {
    const emojis = ['🔥', '✅', '💪', '📚', '🧘', '🚰', '🎯'];
    return AlertDialog(
      title: const Text('Pilih Emoji'),
      content: Wrap(
        spacing: 8,
        children: emojis
            .map((e) => GestureDetector(
                  onTap: () => Navigator.pop(context, e),
                  child: Text(e, style: const TextStyle(fontSize: 28)),
                ))
            .toList(),
      ),
    );
  }
}