package com.example.firebase_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
